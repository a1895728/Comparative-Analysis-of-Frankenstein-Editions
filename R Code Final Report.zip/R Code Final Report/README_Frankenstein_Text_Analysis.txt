READ ME - "Frankenstein Textual Analysis using NLP"

Overview:
This project compares the 1818 and 1831 editions of *Frankenstein* using text analysis techniques: word count, Zipf's Law, wordclouds,TF-IDF, sentiment analysis, bigrams, and more.

Setup:
Ensure the following are available:
1. Text Files: 
   - `frankenstein_1818.txt`
   - `frankenstein_1831.txt`
2. SenticNet Excel File: `senticnet.xlsx`

Required Libraries:
Install libraries using:
```r
install.packages(c("tidyverse", "tidytext", "gutenbergr", "stringr", "udpipe", "textstem", "ggplot2", "ggwordcloud", "ggraph", "igraph", "pacman", "readxl"))
```
Or use `pacman`:
```r
pacman::p_load(tidyverse, tidytext, ggplot2, ggraph, igraph, grid, png, udpipe, textstem, forcats, lexicon, readxl)
```

Input Files:
1. `frankenstein_1818.txt`
2. `frankenstein_1831.txt`
3. `senticnet.xlsx` (in working directory)

Run Data Cleaning:
Use `clean_data_function()` to clean and structure text. This removes metadata, structures text by chapters and sentences, and saves cleaned data as CSV files.

Run Data Analysis:
Use `run_data_analysis()` to conduct:
- Word frequency analysis
- Visualizations (Zipf’s Law, Word Clouds, Bigram Networks)
- Sentiment analysis using SenticNet

Output Files:
Generated files will be saved in:
1. CSV: `frankenstein_cleaned_lemmatized.csv`, `theme_word_counts_cleaned.csv`
2. Visualizations (EPS): `wordcount_raw_by_group.eps`, `wordcloud_frankenstein.eps`, `zipfs_law_frankenstein.eps`, etc.

