######## INSTRUCTIONS ARE AVAILABLE IN THE 'README_FRANKENSTEIN_TEXT_ANALYSIS' FILE #####

### Frankenstein Editions Comparative Analysis - Data Cleaning R code #####

# --- Load Required Libraries ---

library(pacman)
pacman::p_load(tidyverse, tidytext, gutenbergr, stringr, udpipe, textstem,here,ggplot)

# --- Create Output Directory for EPS ---
dir.create("EPS_Graphs", showWarnings = FALSE)
dir.create("Tables", showWarnings = FALSE)


# --- Download Raw Editions -----

#frankenstein_1818_raw <- gutenberg_download(41445, mirror = "http://mirror.csclub.uwaterloo.ca/gutenberg/")
#frankenstein_1831_raw <- gutenberg_download(42324, mirror = "http://mirror.csclub.uwaterloo.ca/gutenberg/")

# -----------------------------------------------------------
# --- Cleaned Data 1a – Standardize Metadata and Identify Structure ---
# -----------------------------------------------------------

dynamic_remove_metadata <- function(book_text) {
  book_text <- tolower(book_text)  # convert entire text to lowercase for consistent pattern matching
  
  # find the start marker line: 'start of the project gutenberg'
  start_index <- which(str_detect(book_text, "start of (the )?project gutenberg"))
  end_index <- which(str_detect(book_text, "end of (the )?project gutenberg"))  # find the end marker line
  
  if (length(start_index) == 0) {  # if not found, check alternative format: '*** start of the project gutenberg'
    start_index <- which(str_detect(book_text, "\\*\\*\\* start of (the )?project gutenberg"))
  }
  if (length(end_index) == 0) {  # if not found, check alternative format: '*** end of the project gutenberg'
    end_index <- which(str_detect(book_text, "\\*\\*\\* end of (the )?project gutenberg"))
  }
  
  if (length(start_index) > 0 & length(end_index) > 0) {  # if both markers found, extract lines between them
    book_text <- book_text[(start_index + 1):(end_index - 1)]
  }
  
  book_text[book_text != ""]  # remove blank lines and return the cleaned text
}


# Function to load a local text file and structure it
load_and_structure_book <- function(file_path, edition_label) {
  raw_book <- readLines(file_path, encoding = "UTF-8")
  text_cleaned <- dynamic_remove_metadata(raw_book)
  book_tbl <- tibble(text = text_cleaned)
  
  structured <- book_tbl %>%
    mutate(
      linenumber = row_number(),
      is_letter = str_detect(text, regex("^letter\\s+[ivxlcdm]+\\.", ignore_case = TRUE)),  # Detect letters
      is_chapter = str_detect(text,regex("^chapter\\s+(\\d+|[ivxlcdm]+)\\.?\\s*$", ignore_case = TRUE)),# Detect chapters
      keep_next = lag(is_letter | is_chapter, default = FALSE),  # Retain text right after header
      letter = cumsum(is_letter),  # Numbering letters
      chapter = cumsum(is_chapter),  # Numbering chapters
      book = edition_label
    ) %>%
    filter(!is_letter & !is_chapter | keep_next) %>%  # Remove headers but keep associated text
    select(book, chapter, text)
  
  return(structured)
}

# --- Load Both Editions ---

this_path <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(this_path)

frankenstein_1818 <- load_and_structure_book("frankenstein_1818.txt", "1818 Edition")
frankenstein_1831 <- load_and_structure_book("frankenstein_1831.txt", "1831 Edition")

# --- Combine Both Editions ---
frankenstein_combined <- bind_rows(frankenstein_1818, frankenstein_1831)


##### Split into sentences ######

split_into_sentences <- function(df) {
  require(dplyr)
  require(tidytext)
  
  df %>%
    unnest_tokens(
      output = sentence,
      input = text,
      token = "sentences"
    ) %>%
    select(book, chapter, sentence)
}

frankenstein_combined_clean <- frankenstein_combined %>%
  group_by(book, chapter) %>%
  summarise(
    text = str_c(text, collapse = " "),
    .groups = "drop"
  )

frankenstein_sentences <- split_into_sentences(frankenstein_combined_clean)

# -----------------------------------------------------------
# Pre-cleaning Summary: Token count BEFORE processing
# -----------------------------------------------------------

raw_summary <- frankenstein_combined %>%
  unnest_tokens(word, text) %>%                    # Tokenize the text column into individual words
  group_by(book) %>%                               # Group by book edition (1818 or 1831)
  summarise(
    Total_Words_Before_Cleaning = n(),             # Count total number of tokens
    Distinct_Words = n_distinct(word),             # Count distinct vocabulary size
    .groups = "drop"
  )

print("Summary before cleaning:")
print(raw_summary)

# -----------------------------------------------------------
# Add Thematic Labels to Each Chapter
# -----------------------------------------------------------

# Create chapter-to-theme mapping with group numbers
theme_labels <- tribble(
  ~book, ~chapter, ~group_no, ~theme,
  "1818 Edition", 0, 1, "Frame_Walton",
  "1818 Edition", 1, 2, "Victor_Origins",
  "1818 Edition", 2, 3, "Scientific_Discovery",
  "1818 Edition", 3, 3, "Scientific_Discovery",
  "1818 Edition", 4, 4, "Creation_Horror",
  "1818 Edition", 5, 4, "Creation_Horror",
  "1818 Edition", 6, 5, "Tragedy_Justice",
  "1818 Edition", 7, 5, "Tragedy_Justice",
  "1818 Edition", 8, 5, "Tragedy_Justice",
  "1818 Edition", 9, 6, "Mountain_Encounter",
  "1818 Edition", 10, 6, "Mountain_Encounter",
  "1818 Edition", 11, 7, "Creature_Learning",
  "1818 Edition", 12, 7, "Creature_Learning",
  "1818 Edition", 13, 8, "Rejection_Revenge",
  "1818 Edition", 14, 8, "Rejection_Revenge",
  "1818 Edition", 15, 8, "Rejection_Revenge",
  "1818 Edition", 16, 9, "Companion_Request",
  "1818 Edition", 17, 9, "Companion_Request",
  "1818 Edition", 18, 10, "Travel_Reflection",
  "1818 Edition", 19, 10, "Travel_Reflection",
  "1818 Edition", 20, 11, "Destruction_Threat",
  "1818 Edition", 21, 12, "Trial_Return",
  "1818 Edition", 22, 12, "Trial_Return",
  "1818 Edition", 23, 13, "Wedding_Death",
  "1831 Edition", 0, 1, "Frame_Walton",
  "1831 Edition", 1, 2, "Victor_Origins",
  "1831 Edition", 2, 2, "Victor_Origins",
  "1831 Edition", 3, 3, "Scientific_Discovery",
  "1831 Edition", 4, 3, "Scientific_Discovery",
  "1831 Edition", 5, 4, "Creation_Horror",
  "1831 Edition", 6, 4, "Creation_Horror",
  "1831 Edition", 7, 5, "Tragedy_Justice",
  "1831 Edition", 8, 5, "Tragedy_Justice",
  "1831 Edition", 9, 5, "Tragedy_Justice",
  "1831 Edition", 10, 6, "Mountain_Encounter",
  "1831 Edition", 11, 6, "Mountain_Encounter",
  "1831 Edition", 12, 7, "Creature_Learning",
  "1831 Edition", 13, 7, "Creature_Learning",
  "1831 Edition", 14, 8, "Rejection_Revenge",
  "1831 Edition", 15, 8, "Rejection_Revenge",
  "1831 Edition", 16, 8, "Rejection_Revenge",
  "1831 Edition", 17, 9, "Companion_Request",
  "1831 Edition", 18, 9, "Companion_Request",
  "1831 Edition", 19, 10, "Travel_Reflection",
  "1831 Edition", 20, 10, "Travel_Reflection",
  "1831 Edition", 21, 11, "Destruction_Threat",
  "1831 Edition", 22, 12, "Trial_Return",
  "1831 Edition", 23, 12, "Trial_Return",
  "1831 Edition", 24, 13, "Wedding_Death"
)

# Save chapter-to-theme mapping table
write_csv(theme_labels, "Tables/chapter_theme_mapping.csv")

# Merge group_no and theme from theme_labels
frankenstein_combined <- frankenstein_combined %>%
  left_join(theme_labels, by = c("book", "chapter"))

# Summarize with the new columns
chapter_word_counts_raw <- frankenstein_combined %>%
  group_by(book, chapter, group_no, theme) %>%
  summarise(word_count = sum(str_count(text, "\\w+")), .groups = "drop")

# Save the file
write_csv(chapter_word_counts_raw, "Tables/chapter_word_counts_raw.csv")


# Summarize with the new columns to sentences
frankenstein_sentences <- frankenstein_sentences %>%
  left_join(theme_labels, by = c("book", "chapter"))


write_csv(frankenstein_sentences, "Tables/frankenstein_sentences_with_group.csv")


# -----------------------------------------------------------
# Cleaned Data 1b – Remove Non-Textual and Redundant Elements (Thematic Grouping)
# -----------------------------------------------------------

frankenstein_combined_grouped <- frankenstein_combined %>%
  group_by(book, group_no, theme) %>%
  summarise(text = paste(text, collapse = " "), .groups = "drop") %>%
  mutate(
    text = text %>%
      str_remove_all("\\[[:print:]+?\\]") %>%
      str_to_lower() %>%
      str_replace_all("[^a-z ]", " ") %>%
      str_squish()
  )

# -----------------------------------------------------------
# Cleaned Data 1c – Text Annotation and Lemmatization via UDPipe
# -----------------------------------------------------------

# Save cleaned grouped text before annotation
write_csv(frankenstein_combined_grouped, "Tables/frankenstein_cleaned_theme_text.csv")

# Download and load the UDPipe English model
ud_model <- udpipe_download_model(language = "english")
ud_model <- udpipe_load_model(ud_model$file_model)

# Assign a text ID for reference
frankenstein_text <- frankenstein_combined_grouped %>%
  mutate(text_id = row_number()) %>%
  select(text_id, book, group_no, theme, text)

# Annotate the text using UDPipe (POS, Lemmas, etc.)
ud_result <- udpipe_annotate(ud_model, x = frankenstein_text$text, doc_id = frankenstein_text$text_id)
ud_df <- as_tibble(ud_result)

# Filter and format annotated tokens
lemmatized_data <- ud_df %>%
  mutate(doc_id = as.integer(doc_id)) %>%
  filter(upos %in% c("NOUN", "VERB", "ADJ", "ADV")) %>%
  filter(!is.na(lemma), nchar(lemma) > 2) %>%
  mutate(word = tolower(lemma)) %>%
  left_join(frankenstein_text, by = c("doc_id" = "text_id")) %>%
  select(book, group_no, theme, word) %>%
  mutate(word = lemmatize_words(word))

# -----------------------------------------------------------
# Cleaned Data 1d – Remove Stopwords and Noise
# -----------------------------------------------------------

data(stop_words)
custom_stopwords <- tibble(word = c("much", "can", "may", "shall", "upon", "however", "yet", "also", "must", "thus", "perhaps", "indeed", "chapter", "letter"))

lemmatized_data <- lemmatized_data %>%
  anti_join(stop_words, by = "word") %>%
  anti_join(custom_stopwords, by = "word")

# -----------------------------------------------------------
# Cleaned Data 1e – Export and Structural Checks
# -----------------------------------------------------------

write_csv(lemmatized_data, "Tables/frankenstein_cleaned_lemmatized.csv")

theme_word_counts <- lemmatized_data %>%
  group_by(book, group_no, theme) %>%
  summarise(word_count = n(), .groups = "drop")

write_csv(theme_word_counts, "Tables/theme_word_counts_cleaned.csv")

# -----------------------------------------------------------
# Cleaned Data 1f – Summary Statistics After Cleaning
# -----------------------------------------------------------

summary_after <- lemmatized_data %>%
  group_by(book) %>%
  summarise(
    `Total Tokens` = n(),
    `Unique Words` = n_distinct(word),
    .groups = "drop"
  )

print("Summary after cleaning:")
print(summary_after)

# -----------------------------------------------------------
# Cleaned Data 1g – Group-wise Word Count Summary for Comparison
# -----------------------------------------------------------

# Load thematic group summaries
theme_cleaned <- read_csv("Tables/theme_word_counts_cleaned.csv") %>% mutate(stage = "Cleaned")

# Also create a synthetic raw version (if needed for comparison)
theme_raw <- frankenstein_combined %>%
  mutate(word_count = str_count(text, "\\w+")) %>%
  group_by(book, group_no, theme) %>%
  summarise(word_count = sum(word_count), .groups = "drop") %>%
  mutate(stage = "Raw")

# Combine both datasets
theme_all <- bind_rows(theme_raw, theme_cleaned)


# Plot 1: Raw Word Counts by Thematic Group (Line Chart)
plot_theme_raw <- ggplot(theme_raw, aes(x = group_no, y = word_count, color = book)) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Raw Word Count per Thematic Group by Edition",
    x = "Group Number", y = "Word Count", color = "Edition"
  ) +
  scale_x_continuous(breaks = unique(theme_raw$group_no)) +
  theme_minimal()

# Plot 2: Cleaned Word Counts by Thematic Group (Line Chart)
plot_theme_clean <- ggplot(theme_cleaned, aes(x = group_no, y = word_count, color = book)) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  labs(
    title = "Cleaned Word Count per Thematic Group by Edition",
    x = "Group Number", y = "Word Count", color = "Edition"
  ) +
  scale_x_continuous(breaks = unique(theme_cleaned$group_no)) +
  theme_minimal()


# Display plots
print(plot_theme_raw)
print(plot_theme_clean)

# Save to EPS
ggsave("EPS_Graphs/wordcount_raw_by_group.eps", plot = plot_theme_raw, device = "eps", width = 8, height = 5)
ggsave("EPS_Graphs/wordcount_cleaned_by_group.eps", plot = plot_theme_clean, device = "eps", width = 8, height = 5)
