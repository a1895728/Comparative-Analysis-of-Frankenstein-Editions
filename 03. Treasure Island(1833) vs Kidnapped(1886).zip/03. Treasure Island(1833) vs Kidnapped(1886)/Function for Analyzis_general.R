clean_and_analyze_twoversion_books <- function(file1_path, file2_path, edition1, edition2, edition_colors = c(), custom_stopwords_list = NULL, section_keywords = c("part", "chapter")) {
  library(tidyverse); library(tidytext); library(stringr)
  library(textstem); library(udpipe); library(ggwordcloud); library(ggraph); library(igraph)
  library(readxl); library(forcats); library(grid); library(png);library(spacyr)
  
  dir.create("EPS_Graphs", showWarnings = FALSE)
  dir.create("Tables", showWarnings = FALSE)
  
  if (is.null(custom_stopwords_list)) {
    custom_stopwords_list <- c("much", "can", "may", "shall", "upon", "however", "yet", "also", "must", "thus", "perhaps", "indeed", "chapter", "letter")
  }
  
  
  # ================================
  # --- Data Cleaning ---
  # ================================
  
  # Function to remove Project Gutenberg metadata
  dynamic_remove_metadata <- function(book_text) {
    book_text <- tolower(book_text)
    start_index <- which(str_detect(book_text, "start of (the )?project gutenberg|\\*\\*\\* start"))
    end_index <- which(str_detect(book_text, "end of (the )?project gutenberg|\\*\\*\\* end"))
    if (length(start_index) > 0 & length(end_index) > 0) {
      book_text <- book_text[(start_index + 1):(end_index - 1)]
    }
    book_text[book_text != ""]
  }
  
  # Load and structure chapters
  load_and_structure_book <- function(file_path, edition_label) {
    raw_book <- readLines(file_path, encoding = "UTF-8")
    cleaned <- dynamic_remove_metadata(raw_book)
    section_keywords_regex <- paste(section_keywords, collapse = "|")
    tibble(text = cleaned) %>%
      mutate(
        linenumber = row_number(),
        is_letter = str_detect(text, regex("^letter\\s+[ivxlcdm]+\\.", ignore_case = TRUE)),
        is_section = str_detect(text, regex(paste("^", section_keywords_regex, "\\s*(\\d+|[ivxlcdm]+)\\s*--?.*\\s*$", sep = ""), ignore_case = TRUE)),
        keep_next = lag(is_letter | is_section, default = FALSE),
        letter = cumsum(is_letter),
        chapter = cumsum(is_section),
        book = edition_label
      ) %>%
      filter(!is_letter & !is_section | keep_next) %>%
      select(book, chapter, text)
  }
  
  # Load and combine books
  book_1 <- load_and_structure_book(file1_path, edition1)
  book_2 <- load_and_structure_book(file2_path, edition2)
  book_combined <- bind_rows(book_1, book_2)
  
  # Word Count Before Cleaning
  book_raw_counts <- book_combined %>%
    mutate(text = str_squish(text)) %>%
    group_by(book, chapter) %>%
    summarise(word_count = sum(str_count(text, "\\S+")), .groups = "drop")
  
  raw_plot <- ggplot(book_raw_counts, aes(x = chapter, y = word_count, color = book)) +
    geom_line(linewidth = 1.1) + geom_point(size = 2) +
    scale_color_manual(values = edition_colors) +
    labs(title = "Chapter-wise Word Count (Before Cleaning)", x = "Chapter", y = "Word Count") +
    theme_minimal(base_size = 13)
  
  ggsave("EPS_Graphs/chapter_wordcount_raw.eps", plot = raw_plot, device = "eps", width = 10, height = 6)
  print(raw_plot)
  
  
  book_grouped <- book_combined %>%
    group_by(book, chapter) %>%
    summarise(text = paste(text, collapse = " "), .groups = "drop") %>%
    mutate(
      text = text %>%
        str_remove_all("\\[[:print:]+?\\]") %>%
        str_to_lower() %>%
        str_replace_all("[^a-z ]", " ") %>%
        str_squish()
    )
  
  # Load UDPipe model
  model_info <- udpipe_download_model(language = "english", model_dir = tempdir(), overwrite = FALSE)
  ud_model <- udpipe_load_model(model_info$file_model)
  
  # Annotate text
  book_text <- book_grouped %>% mutate(text_id = row_number()) %>% select(text_id, book, chapter, text)
  ud_result <- udpipe_annotate(ud_model, x = book_text$text, doc_id = book_text$text_id)
  ud_df <- as_tibble(ud_result)
  
  lemmatized_data <- ud_df %>%
    mutate(doc_id = as.integer(doc_id)) %>%
    filter(upos %in% c("NOUN", "VERB", "ADJ", "ADV")) %>%
    filter(!is.na(lemma), nchar(lemma) > 2) %>%
    mutate(word = tolower(lemma)) %>%
    left_join(book_text, by = c("doc_id" = "text_id")) %>%
    select(book, chapter, word) %>%
    mutate(word = lemmatize_words(word))
  
  # Remove stopwords
  data(stop_words)
  custom_stopwords <- tibble(word = custom_stopwords_list)
  lemmatized_data <- lemmatized_data %>%
    anti_join(stop_words, by = "word") %>%
    anti_join(custom_stopwords, by = "word")
  
  write_csv(lemmatized_data, "Tables/cleaned_lemmatized.csv")
  
  # Word Count After Cleaning
  clean_counts <- lemmatized_data %>%
    count(book, chapter, name = "word_count")
  
  clean_plot <- ggplot(clean_counts, aes(x = chapter, y = word_count, color = book)) +
    geom_line(linewidth = 1.1) + geom_point(size = 2) +
    scale_color_manual(values = edition_colors) +
    labs(title = "Chapter-wise Word Count (After Cleaning)", x = "Chapter", y = "Word Count") +
    theme_minimal(base_size = 13)
  
  ggsave("EPS_Graphs/chapter_wordcount_clean.eps", plot = clean_plot, device = "eps", width = 10, height = 6)
  print(clean_plot)
  
  
  # ================================
  # --- Data Analyzing ---
  # ================================
  
  # Zipf's Law
  freq_rank <- lemmatized_data %>%
    count(book, word, sort = TRUE) %>%
    group_by(book) %>%
    mutate(rank = row_number(), term_frequency = n / sum(n)) %>%
    ungroup()
  
  zipf_plot <- ggplot(freq_rank, aes(rank, term_frequency, color = book)) +
    geom_line(linewidth = 1.1) +
    scale_x_log10() + scale_y_log10() +
    labs(title = "Zipf’s Law", x = "Rank (log)", y = "Frequency (log)", color = "Edition") +
    scale_color_manual(values = edition_colors) +
    theme_minimal()
  ggsave("EPS_Graphs/zipfs_law.eps", plot = zipf_plot, device = "eps")
  print(zipf_plot)
  
  # Wordcloud
  top_words <- lemmatized_data %>% count(book, word, sort = TRUE) %>% group_by(book) %>% slice_max(n, n = 100) %>% ungroup()
  wordcloud_plot <- ggplot(top_words, aes(label = word, size = n, color = book)) +
    geom_text_wordcloud_area() +
    facet_wrap(~book) + theme_minimal() +
    scale_color_manual(values = edition_colors)
  ggsave("EPS_Graphs/wordcloud.eps", plot = wordcloud_plot, device = "eps")
  print(wordcloud_plot)
  
  # Top 20 Words
  top20_words <- lemmatized_data %>%
    count(book, word, sort = TRUE) %>%
    group_by(book) %>% slice_max(n, n = 20) %>% ungroup() %>%
    mutate(word = reorder_within(word, n, book))
  top20_plot <- ggplot(top20_words, aes(x = n, y = word, fill = book)) +
    geom_col(show.legend = FALSE) +
    facet_wrap(~book, scales = "free_y") +
    scale_y_reordered() +
    scale_fill_manual(values = edition_colors) +
    labs(title = "Top 20 Words per Edition", x = "Frequency", y = NULL) +
    theme_minimal(base_size = 13) +
    theme(strip.text = element_text(face = "bold"))
  ggsave("EPS_Graphs/top20_words_per_edition.eps", plot = top20_plot, device = "eps", width = 10, height = 6)
  print(top20_plot)
  
  # Named Entity Recognition (NER): Top 6 Entity Types Plot
  library(spacyr)
  
  spacyr::spacy_initialize(model = "en_core_web_sm")
  
  # Assign doc_id for NER input
  book_grouped <- book_grouped %>%
    mutate(doc_id = paste(book, chapter, sep = "_"))
  
  # Extract NER
  ner_data <- spacyr::spacy_extract_entity(book_grouped, text_field = "text")
  
  # Clean & summarize NER output
  ner_summary <- ner_data %>%
    tidyr::separate(doc_id, into = c("book", "chapter"), sep = "_", remove = FALSE) %>%
    dplyr::mutate(chapter = as.integer(chapter)) %>%
    group_by(book, chapter, ent_type) %>%
    summarise(count = n(), .groups = "drop")
  
  # Determine top 6 entity types overall
  top6_entities <- ner_summary %>%
    group_by(ent_type) %>%
    summarise(total = sum(count)) %>%
    slice_max(order_by = total, n = 6) %>%
    pull(ent_type)
  
  ner_top6 <- ner_summary %>%
    filter(ent_type %in% top6_entities)
  
  # Plot: Faceted by Entity Type, with lines for each edition
  ner_plot <- ggplot(ner_top6, aes(x = chapter, y = count, color = book)) +
    geom_line(linewidth = 1) +
    facet_wrap(~ent_type, scales = "free_y") +
    labs(
      title = "Top 6 Named Entity Types by Chapter (1818 vs 1831 Editions)",
      x = "Chapter", y = "Entity Count", color = "Edition"
    ) +
    scale_color_manual(values = edition_colors) +
    theme_minimal(base_size = 13)
  
  ggsave("EPS_Graphs/ner_top6_facet_edition.eps", plot = ner_plot, device = "eps", width = 11, height = 6.5)
  print(ner_plot)
  
  spacyr::spacy_finalize()
  

  # --- TF-IDF Analysis ---
  tf_idf_df <- lemmatized_data %>%
    count(book, word, sort = TRUE) %>%
    bind_tf_idf(word, book, n)
  
  top_tf_idf <- tf_idf_df %>%
    group_by(book) %>%
    slice_max(tf_idf, n = 10) %>%
    ungroup() %>%
    mutate(word = reorder_within(word, tf_idf, book))
  
  tfidf_plot <- ggplot(top_tf_idf, aes(x = tf_idf, y = word, fill = book)) +
    geom_col(show.legend = FALSE) +
    facet_wrap(~book, scales = "free_y") +
    scale_y_reordered() +
    scale_fill_manual(values = edition_colors) +
    labs(
      title = "Top TF-IDF Words by Edition",
      x = "TF-IDF Score", y = NULL
    ) +
    theme_minimal()
  
  print(tfidf_plot)
  ggsave("EPS_Graphs/tfidf_top_words.eps", plot = tfidf_plot, device = "eps")
  
  # --- Sentiment Analysis by Chapter Count ---
  senticnet <- read_excel("senticnet.xlsx") %>%
    rename(word = `CONCEPT`, score = `POLARITY INTENSITY`) %>%
    select(word, score)
  
  sentiment_df <- lemmatized_data %>%
    count(book, chapter, word) %>%
    inner_join(senticnet, by = "word") %>%
    mutate(contribution = n * score)
  
  sentiment_summary <- sentiment_df %>%
    group_by(book, chapter) %>%
    summarise(weighted_sentiment = mean(score), .groups = "drop")
  
  sentiment_plot <- ggplot(sentiment_summary, aes(x = chapter, y = weighted_sentiment, color = book)) +
    geom_line(linewidth = 1.1) + geom_point(size = 2) +
    theme_minimal() +
    scale_color_manual(values = edition_colors) +
    labs(title = "Sentiment by Chapter", x = "Chapter", y = "Avg. Score")
  
  print(sentiment_plot)
  ggsave("EPS_Graphs/sentiment_by_chapter.eps", plot = sentiment_plot, device = "eps")
  
  # --- Top 15 Positive and Negative Words ---
  word_freq <- lemmatized_data %>%
    count(book, word, sort = TRUE)
  
  sentiment_data <- word_freq %>%
    inner_join(senticnet, by = "word") %>%
    mutate(sentiment = ifelse(score >= 0, "Positive", "Negative"))
  
  top_sentiment_words <- sentiment_data %>%
    group_by(book, sentiment) %>%
    slice_max(n, n = 15) %>%
    ungroup() %>%
    mutate(word = reorder_within(word, n, book))
  
  sentiment_word_plot <- ggplot(top_sentiment_words, aes(x = n, y = word, fill = sentiment)) +
    geom_col(show.legend = FALSE) +
    facet_wrap(~sentiment + book, scales = "free_y") +
    scale_y_reordered() +
    scale_fill_manual(values = c("Positive" = "#7CCD7C", "Negative" = "#F08080")) +
    labs(title = paste("Top Sentiment Words in", edition1, "vs", edition2), x = "Frequency", y = NULL) +
    theme_minimal(base_size = 13)
  
  print(sentiment_word_plot)
  ggsave("EPS_Graphs/top_sentiment_words_senticnet.eps", plot = sentiment_word_plot, device = "eps", width = 10, height = 6)
  
  
  # --- Top Sentiment Contributors ---
  sentiment_df <- lemmatized_data %>%
    count(book, word) %>%
    inner_join(senticnet, by = "word") %>%
    mutate(contribution = n * score)
  
  top_sentiment <- sentiment_df %>%
    group_by(book) %>%
    slice_max(abs(contribution), n = 30) %>%
    ungroup() %>%
    mutate(word = fct_reorder2(word, book, contribution))
  
  sentiment_plot_contribution <- ggplot(top_sentiment, aes(x = contribution, y = word, fill = contribution > 0)) +
    geom_col(show.legend = FALSE) +
    facet_wrap(~book, scales = "free_y") +
    scale_y_reordered() +
    scale_fill_manual(values = c("TRUE" = "#7CCD7C", "FALSE" = "#F08080")) +
    labs(title = "Top Sentiment Contributors (Frequency × Score)", x = "Contribution", y = NULL) +
    theme_minimal(base_size = 13)
  
  print(sentiment_plot_contribution)
  ggsave("EPS_Graphs/senticnet_sentiment_contributors.eps", plot = sentiment_plot_contribution, device = "eps", width = 10, height = 6)
  
  
  # --- Bigram Network ---

  # Remove edition titles before bigramming
  book_texts <- lemmatized_data %>%
    filter(!word %in% c(edition1, edition2)) %>%  # Ensure edition names aren't included as "words"
    group_by(book) %>%
    summarise(text = paste(word, collapse = " "), .groups = "drop")
  
  bigrams_df <- book_texts %>%
    unnest_tokens(bigram, text, token = "ngrams", n = 2) %>%
    separate(bigram, into = c("word1", "word2"), sep = " ") %>%
    filter(
      !word1 %in% stop_words$word,
      !word2 %in% stop_words$word,
      !word1 %in% c(edition1, edition2),
      !word2 %in% c(edition1, edition2),
      !is.na(word1), !is.na(word2)
    ) %>%
    count(book, word1, word2, sort = TRUE)
  
  # Function to plot bigram graph (edition title not included as node)
  plot_bigram_graph <- function(book_name, color) {
    bigram_data <- bigrams_df %>%
      filter(book == book_name) %>%
      slice_max(n, n = 30) %>%
      select(word1, word2, n)
    
    graph <- graph_from_data_frame(bigram_data, directed = TRUE)
    
    ggraph(graph, layout = "fr") +
      geom_edge_link(
        aes(edge_alpha = n),
        arrow = grid::arrow(type = "closed", length = unit(0.15, "inches")),
        end_cap = circle(0.07, "inches"),
        show.legend = FALSE,
        color = color
      ) +
      geom_node_point(color = color) +
      geom_node_text(aes(label = name), repel = TRUE, size = 3) +
      labs(title = paste("Bigram Network for", book_name)) +
      theme_minimal(base_size = 13) +
      theme(
        axis.title = element_blank(),
        axis.text = element_blank(),
        axis.ticks = element_blank()
      )
  }
  
  
  color1 <- edition_colors[[edition1]]
  color2 <- edition_colors[[edition2]]
  
  plot_1 <- plot_bigram_graph(edition1, color1)
  plot_2 <- plot_bigram_graph(edition2, color2)
  
  print(plot_1) 
  print(plot_2)
  
  cairo_ps("EPS_Graphs/bigram_edition1.eps", width = 8, height = 6)
  print(plot_1)
  dev.off()
  
  cairo_ps("EPS_Graphs/bigram_edition2.eps", width = 8, height = 6)
  print(plot_2)
  dev.off()
  
  message("✔ Analysis complete. Results saved in 'EPS_Graphs' and 'Tables' folders.")
}



# ================================
# --- Run the Function ---
# ================================

clean_and_analyze_twoversion_books(
  file1_path = "Treasure_island.txt",
  file2_path = "Kidnapped.txt",
  edition1 = "Treasure Island Edition",
  edition2 = "Kidnapped Edition",
  edition_colors = c(
    "Treasure Island Edition" = "#FF4500",  # Orange Red (vibrant, adventure theme for Treasure Island)
    "Kidnapped Edition" = "#32CD32"         # Lime Green (vibrant and adventurous theme for Kidnapped)
  ),
  custom_stopwords_list = c("chapter", "letter", "shall", "must", "thus", "indeed", "however", "also"),
  section_keywords = c("part", "chapter")  # Update this to match section headings like "PART", "I", etc.
)






