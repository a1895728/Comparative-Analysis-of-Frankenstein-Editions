README: Function Accuracy Checking

The following book comparisons are being used for accuracy checking of the function:

1. The Picture of Dorian Gray (1890 vs 1891)  
- Function worked well.

2. Frankenstein (1818) vs Dracula (1897)  
- Function worked well.

3. Treasure Island (1833) vs Kidnapped (1886)  
- Function worked well except for the chapter-level analysis.  
- The code needs improvement to handle different forms of chapter splits (e.g., Chapter, Parts, etc.).

