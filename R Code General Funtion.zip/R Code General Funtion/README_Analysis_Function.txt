
Analysis of Two Book Editions (`clean_and_analyze_twoversion_books`)

### Overview:
The `clean_and_analyze_twoversion_books` function is designed to analyze and compare two editions of literary texts using text cleaning, lemmatization, and statistical analysis techniques. It performs multiple analyses, including **word counts**, **Zipf's law**, **word clouds**, **Named Entity Recognition (NER)**, **TF-IDF**, and **sentiment analysis**. The results of these analyses are saved as **EPS files** for visualizations and **CSV files** for data storage.

### Function Workflow:
1. **Text Cleaning**:
   - The function removes metadata from the Project Gutenberg files (e.g., Project Gutenberg headers).
   - It processes the text to remove unwanted characters, convert it to lowercase, and lemmatize the words.
   - Custom stopwords (e.g., "chapter", "letter") can be excluded from the analysis.

2. **Data Analysis**:
   - **Word Count Analysis**: Conducted before and after text cleaning.
   - **Zipf’s Law**: A plot showing the relationship between word rank and frequency in the text.
   - **Word Cloud**: Visual representation of the most frequent words.
   - **Top 20 Words**: A plot displaying the most common words in each edition.
   - **Named Entity Recognition (NER)**: Extraction and visualization of the most common entity types (e.g., PERSON, GPE).
   - **TF-IDF**: Identifies words that are most important in the context of each book edition.
   - **Sentiment Analysis**: Analyzes the sentiment of each chapter based on predefined word scores.

### Folder Structure:
- **EPS_Graphs**: All visual outputs (e.g., plots, graphs) are saved here in **EPS format**.
- **Tables**: Contains **CSV files** with cleaned and lemmatized data (e.g., word count, lemmatized words).

### File Input:
- The function requires **two text files** as input: one for each book edition downloaded from 'Gothenburg'. 
Example:
  - `"book1.txt"`
  - `"book2.txt"`

Custom Stopwords:
- A custom list of stopwords can be passed to exclude common words (e.g., "the", "and", or "chapter").

### Function Usage:
To run the function, provide the following parameters:
- **`file1_path`**: Path to the first book text file.
- **`file2_path`**: Path to the second book text file.
- **`edition1`**: Label for the first book edition (e.g., "Edition 1").
- **`edition2`**: Label for the second book edition (e.g., "Edition 2").
- **`edition_colors`**: Colors for the visualizations (e.g., `c("Edition 1" = "midnightblue", "Edition 2" = "firebrick")`).
- **`custom_stopwords_list`**: Optional list of custom stopwords to remove from the analysis.

### Output:
- **EPS_Graphs Folder**:
  - **Chapter-wise Word Count (Before Cleaning)**: A plot of word counts for each chapter before cleaning.
  - **Chapter-wise Word Count (After Cleaning)**: Word count after text cleaning and lemmatization.
  - **Zipf’s Law Plot**: A plot showing Zipf’s law distribution of word frequencies.
  - **Word Cloud**: A visual representation of the top 100 most frequent words.
  - **Top 20 Words per Edition**: A bar plot of the top 20 most frequent words.
  - **NER Top 6 Entity Types Plot**: A plot of the most frequent named entity types (e.g., PERSON, ORGANIZATION, LOCATION).
  - **TF-IDF Analysis Plot**: A plot of the top 10 terms in each edition based on Term Frequency-Inverse Document Frequency.
  - **Sentiment by Chapter Plot**: A plot showing the sentiment distribution for each chapter.
  - **Top Sentiment Words**: The top 15 positive and negative words based on sentiment scoring.

- **Tables Folder**:
  - **cleaned_lemmatized.csv**: Contains the lemmatized word data after cleaning, with columns for book edition, chapter, and word frequency.

### Example Report Template:

**Introduction**:  
This report presents a comparison of two editions outputs obtained from the general function in the PDF format.

**Note**:
Make sure to keep both R scripts in the same location.
Ensure that the 'title', 'author', 'edition1', and 'edition2' parameters are updated with the correct book editions before running the report.

**Content**:
**Data Cleaning**:  
The data was cleaned by removing irrelevant metadata from the books and lemmatizing the text. Custom stopwords were also excluded from the analysis.

**Word Count Analysis**:  
- **Before Cleaning**:  
  A plot displaying the word counts for each chapter before cleaning.
  
- **After Cleaning**:  
  A plot displaying the word counts for each chapter after cleaning.

**Zipf’s Law**:  
A plot showing Zipf’s law distribution of word frequencies.

**Named Entity Recognition (NER)**:  
A plot showing the most frequent named entity types (e.g., PERSON, GPE, ORGANIZATION).

**Sentiment Analysis**:  
A plot showing sentiment trends by chapter for both editions.

### Conclusion:
The analysis reveals distinct differences in word frequency distributions, sentiment, and entity recognition between the two editions. These findings offer valuable insights into the stylistic evolution between the books/editions of the literary works.


